package yu.demo.mytoos.fast;

public interface IFast {

    String getTargetPath ();

    String getModifyLineStart ();

    String getModifyLineContent ();


}
