package yu.demo.mytoos.engadapter;

public class YoudaoApi {
    public String youdaoAppId;
    public String youdaoAppKey;
}
